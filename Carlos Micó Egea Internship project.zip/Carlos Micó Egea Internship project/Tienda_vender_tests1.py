import modulo_prueba
import unittest


class TestMethods(unittest.TestCase):

    def test_vender(self):
        A = modulo_prueba.Tienda(200, 20)
        A.vender(100, 15)
        self.assertEqual(A.ganancias, 300)
        self.assertEqual(A.stock, 5)


suite = unittest.TestLoader().loadTestsFromTestCase(TestMethods)
resultado = unittest.TextTestRunner(verbosity=2).run(suite)
