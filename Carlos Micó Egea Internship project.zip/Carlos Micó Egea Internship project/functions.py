import math
import item
from item import item

def InterestPayment(money,rate,years):
	
	interest=money*rate*years
	return interest
	
def PositiveOrNegative(number):
	if type(number)==int or type(number)==float:
		if number>0:
			result="positive"
		if number==0:
			result="zero"
		if number<0:
			result="negative"
	if type(number)!=float and type(number)!=int:
		result="error"
	return result

def Backto5(number):
	if type(number)==int:
		if number>5:
			result=5
		if number==5:
			result=True
		if number<5:
			result=5
	if type(number)!=float and type(number)!=int:
		result="error"
	return result
	
	
def NumberWithoutComma(number):
	if type(number)==int:
		result=number
	else:
		if type(number)==float:
			if number>0:
				result=int(math.floor(number))
			else:
				result=int(math.ceil(number))
		if type(number)!=float:
			result="error"
	return result
		
def ReverseWord(string):
	return string[::-1]

def Identity(thing):
	return thing
		
def ListOfAttributes(item):
	Attributes=[item.name,item.quality,item.price,item.RemainingAmount]
	return Attributes
		
		
		
		