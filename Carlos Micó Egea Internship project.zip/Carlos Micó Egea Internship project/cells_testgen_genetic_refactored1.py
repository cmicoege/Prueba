import functions
from cell_get_tests_genetic_refactored1 import cell_create_tests_genetic

'''
#modulo_prueba, resta
module_name = "modulo_prueba"
function_name = "resta"

variables = [[10,5],[20,10]]
expected_value = [[5],[10]]




tests1=cell_create_tests_genetic(variables, expected_value, module_name, function_name)


try:
    file = open(function_name + "_tests1.py","w") 
    file.write(tests1) 
    print("Saved in {}".format(function_name + "_tests1_.py"))
    file.close() 
except:
    for i in range(0,len(tests1)):
        file = open(function_name + "_tests1_"+str(i+1)+".py","w") 
        file.write(tests1[i]) 
        print("Saved in {}".format(function_name+"_tests1_"+str(i+1)+".py"))
        file.close() 

'''


'''

#modulo_prueba, Tienda, vender

module_name = "modulo_prueba"
class_name = "Tienda"
atributes = ["ganancias"]
method_name = "ganar_dinero"


variables = [[200,0]]
method_input = [[100]]
expected_value = [[300]]


tests2=cell_create_tests_genetic(variables, expected_value, module_name, None, class_name, atributes, method_name, method_input)


try:
    file = open(class_name + "_" + method_name + "_tests2.py","w") 
    file.write(tests2) 
    print("Saved in {}".format(class_name + "_" + method_name + "_tests2.py"))
    file.close() 
except:
    for i in range(0,len(tests2)):
        file = open(class_name + "_" + method_name + "_tests2_"+str(i+1)+".py","w") 
        file.write(tests2[i]) 
        print("Saved in {}".format(class_name+"_"+method_name+"_tests2_"+str(i+1)+".py"))
        file.close() 

'''


module_name = "modulo_prueba"
class_name = "Tienda"
atributes = ["ganancias", "stock"]
method_name = "vender"


variables = [[200,20]]
method_input = [[100,15]]
expected_value = [[300,5]]



tests=cell_create_tests_genetic(variables, expected_value, module_name, None, class_name, atributes, method_name, method_input)

#print(tests)
try:
    for test in tests:
        print(test)
except:
    pass


try:
    file = open(class_name + "_" + method_name + "_tests.py","w") 
    file.write(tests) 
    print("Saved in {}".format(class_name + "_" + method_name + "_tests.py"))
    file.close() 
except:
    for i in range(0,len(tests)):
        file = open(class_name + "_" + method_name + "_tests"+str(i+1)+".py","w") 
        file.write(tests[i]) 
        print("Saved in {}".format(class_name+"_"+method_name+"_tests"+str(i+1)+".py"))
        file.close() 
