from ast import *
from astor import to_source
import random
import copy
import numpy as np
from numpy.random import choice
from training_matrixes import get_index, read_matrix, save_matrix, calculate_weight, get_before_matrix, get_inside_matrix
from training_matrixes import modify_Before_matrix, modify_Inside_matrix, modify_Before_matrix_insert_in, modify_Inside_matrix_insert_in
#from training_matrixes import modify_Before_matrix_insert_first_node_in, modify_Inside_matrix_insert_first_node_in


class Individual:
    def __init__(self, tree, cells=None, Before_matrix=None, Inside_matrix=None, collection_of_nodes=None):
        self.tree = tree
        self.cells = cells
        self.Before_matrix = Before_matrix
        self.Inside_matrix = Inside_matrix
        self.collection_of_nodes = collection_of_nodes

def make_blank_population(module_name, amount_of_trees):
    file = open("hardcoded_part_code.py", 'r')
    code = file.read()  # code of the blank test
    import_node = Import(names=[alias(name=module_name, asname=None)])
    population = []
    for _ in range(0, amount_of_trees):
        individuo = Individual(parse(code))
        # Insert the correct Import in our tree
        individuo.tree.body.insert(0, import_node)
        population.append(individuo)

    return population


def make_nodes(var, expectval, methinp, module_name, class_name, function_name, test_name, method_name, atributes, assert_type):

    var_A = Name(id="A")

    A = FunctionDef(name=test_name,
            args=arguments(args=[arg(arg='self', annotation=None)],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]),
            body=[],
            decorator_list=[],
            returns=None)

    B = Assign(targets=[var_A],
                value=Call(func=Attribute(value=Name(id=module_name), attr=function_name),
                            args=var,
                            keywords=[]))


    C = Expr(
        value=Call(func=Attribute(value=Name(id='self'), attr=assert_type),
                    args=[var_A] + expectval,
                    keywords=[]))

    D=Assign(targets=[var_A],
            value=Call(func=Attribute(value=Name(id=module_name), attr=class_name),
                args=var,
                keywords=[]))

    E=Expr(
            value=Call(func=Attribute(value=var_A, attr=method_name),
                args=methinp,
                keywords=[]))

    F=[]
    for i in range(0, len(atributes)):
        Node = Expr(
            value=Call(func=Attribute(value=Name(id='self'), attr=assert_type),
                    args=[
                    Attribute(value=var_A, attr=atributes[i]), expectval[i]],
                    keywords=[]))
        F.append(Node)
    
    return [A,B,C,D,E,*F]

def function_core_nodes(module_name):
    M=Module(body=[])

    I1=Import(names=[alias(name=module_name, asname=None)])

    I2 = Import(names=[alias(name='unittest', asname=None)])

    Class_node = ClassDef(name='TestMethods',
                bases=[Attribute(value=Name(id='unittest'), attr='TestCase')],
                keywords=[],
                body=[],
                decorator_list=[])

    suite=Assign(targets=[Name(id='suite')],
                value=Call(
                    func=Attribute(
                        value=Call(func=Attribute(value=Name(id='unittest'), attr='TestLoader'), args=[], keywords=[]),
                        attr='loadTestsFromTestCase'),
                    args=[Name(id='TestMethods')],
                    keywords=[]))

    run=Assign(targets=[Name(id='resultado')],
                value=Call(
                    func=Attribute(
                        value=Call(func=Attribute(value=Name(id='unittest'), attr='TextTestRunner'),
                            args=[],
                            keywords=[keyword(arg='verbosity', value=Num(n=2))]),
                        attr='run'),
                    args=[Name(id='suite')],
                    keywords=[]))
    Pass_node= Pass()

    return [M,I1,I2,Class_node, suite, run, Pass_node]


def softmax(x):
    """Compute softmax values for each sets of scores in x."""
    '''e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()'''
    suma = sum(x)
    if suma != 0:
        result = []
        for element in x:
            result.append(element / suma)
    else:
        result = x
    return result


def insert_nodes(individuo):
    
    Temp_Cells = individuo.cells
    Before_average_matrix = read_matrix('BeforeAverageMatrix.txt')
    Inside_average_matrix = read_matrix('InsideAverageMatrix.txt')
    
    for elem_body1 in individuo.tree.body:

        '''
        if Temp_Cells != []:
                weight_list = []
                for node in Temp_Cells:
                    Before_matrix = individuo.Before_matrix
                    Inside_matrix = individuo.Inside_matrix
                    previous_node = copy.deepcopy(elem_body1)
                    if hasattr(previous_node, 'body'):
                        previous_node.body = []
                    if hasattr(previous_node, 'name'):
                        previous_node.name = None
                    Before_matrix = modify_Before_matrix(node, previous_node, individuo.collection_of_nodes,
                                                        Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix(
                    node, previous_node, individuo.collection_of_nodes,  Inside_matrix)
                    weight = calculate_weight(
                        node, individuo.collection_of_nodes, Before_matrix, Inside_matrix, Before_average_matrix, Inside_average_matrix)
                    weight_list.append(weight)
                softmax_weights = softmax(weight_list)
                Choice = choice(Temp_Cells, 1, p=softmax_weights)
                index_of_Choice = Temp_Cells.index(Choice)

                R = random.randint(1, 1000)
                R = R / 1000

                if R <= weight_list[index_of_Choice]:
                    individuo.tree.body.insert(
                        individuo.tree.body.index(elem_body1) + 1, Choice)
                    Temp_Cells.remove(Choice)
                    individuo.Before_matrix = Before_matrix
                    individuo.Inside_matrix = Inside_matrix
        '''
        if not hasattr(elem_body1, 'body'):
            continue
        #######
        if Temp_Cells != []:
                weight_list = []
                sum_of_differences_list = []

                for node in Temp_Cells:

                    Before_matrix = copy.deepcopy(individuo.Before_matrix)
                    Inside_matrix = copy.deepcopy(individuo.Inside_matrix)

                    father_node=copy.deepcopy(elem_body1)

                    if hasattr(father_node, 'body'):
                        father_node.body = []
                    if hasattr(father_node, 'name'):
                        father_node.name = None
                    
                    Before_matrix = modify_Before_matrix_insert_in(node, father_node, individuo.collection_of_nodes,
                                Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix_insert_in(node, father_node, individuo.collection_of_nodes,  Inside_matrix)
                    weight, sum_of_differences = calculate_weight(
                        node, individuo.collection_of_nodes, Before_matrix, Inside_matrix, Before_average_matrix, Inside_average_matrix)
                    weight_list.append(weight)
                    sum_of_differences_list.append(sum_of_differences)

                softmax_weights = softmax(weight_list)
                '''print("desde fuera")
                print(father_node)
                print("sum_of_differences_list")
                print(sum_of_differences_list)
                print(weight_list)
                print(softmax_weights)
                print("temp_cells:")
                print(Temp_Cells)'''
                index_list = [get_index(node, individuo.collection_of_nodes) for node in Temp_Cells]
                #print(index_list)
                #if sum(softmax_weights)!=0:
                Choice = choice(Temp_Cells, 1, p=softmax_weights)[0]
                #Choice = Temp_Cells[weight_list.index(max(weight_list))]
                index_of_Choice = Temp_Cells.index(Choice)
                '''print("de esos hemos elegido el numero {}".format(index_of_Choice))
                print("es decir, el {}".format(get_index(Choice, individuo.collection_of_nodes)))
                print(dump(Choice))'''
                if len(elem_body1.body)==0 or (len(elem_body1.body)==1 and type(elem_body1.body[0])==Pass):
                    R=0
                else:
                    R = random.randint(1, 1000)
                    R = R / 1000

                if R <= weight_list[index_of_Choice]:
                    elem_body1.body.insert(0, Choice)
                    Temp_Cells.remove(Choice)
                    Before_matrix = modify_Before_matrix_insert_in(Choice, father_node, individuo.collection_of_nodes,
                                Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix_insert_in(Choice, father_node, individuo.collection_of_nodes,  Inside_matrix)
                    
                    individuo.Before_matrix=Before_matrix
                    individuo.Inside_matrix=Inside_matrix

        #########
        for elem_body2 in elem_body1.body:
            if Temp_Cells != []:
                weight_list = []
                sum_of_differences_list = []

                for node in Temp_Cells:

                    Before_matrix = copy.deepcopy(individuo.Before_matrix)
                    Inside_matrix = copy.deepcopy(individuo.Inside_matrix)

                    previous_node=copy.deepcopy(elem_body2)

                    if hasattr(previous_node, 'body'):
                        previous_node.body = []
                    if hasattr(previous_node, 'name'):
                        previous_node.name = None
                    
                    Before_matrix = modify_Before_matrix(node, previous_node, individuo.collection_of_nodes, 
                                Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix(node, previous_node, individuo.collection_of_nodes,  Inside_matrix)
                    weight, sum_of_differences = calculate_weight(
                        node, individuo.collection_of_nodes, Before_matrix, Inside_matrix, Before_average_matrix, Inside_average_matrix)
                    weight_list.append(weight)
                    sum_of_differences_list.append(sum_of_differences)
                '''print("desde dentro")
                print(previous_node)
                print("sum_of_differences_list")
                print(sum_of_differences_list)
                print("weight_list")
                print(weight_list)'''
                softmax_weights = softmax(weight_list)
                '''print("softmax weights")
                print(softmax_weights)
                print("temp_cells:")
                print(Temp_Cells)'''
                #if sum(softmax_weights) != 0:
                Choice = choice(Temp_Cells, 1, p=softmax_weights)[0]
                #Choice=Temp_Cells[weight_list.index(max(weight_list))]
                index_of_Choice = Temp_Cells.index(Choice)
                R = random.randint(1, 1000)
                R = R / 1000
                #print("choice")
                #print(Choice)
                if R <= weight_list[index_of_Choice]:
                    elem_body1.body.insert(
                        elem_body1.body.index(elem_body2) + 1, Choice)
                    Temp_Cells.remove(Choice)

                    Before_matrix = modify_Before_matrix(Choice, previous_node, individuo.collection_of_nodes,
                                Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix(Choice, previous_node, individuo.collection_of_nodes,  Inside_matrix)

                    individuo.Before_matrix=Before_matrix
                    individuo.Inside_matrix=Inside_matrix
                    #print("individuo.tree.body[2].body:")
                    #print(individuo.tree.body[2].body)

            if not hasattr(elem_body2, 'body'):
                continue

            if Temp_Cells != []: ####añadir el caso de que añadimos en la primera casilla aunque ya haya nodos
                weight_list = []
                sum_of_differences_list = []

                for node in Temp_Cells:
                    Before_matrix = copy.deepcopy(individuo.Before_matrix)
                    Inside_matrix = copy.deepcopy(individuo.Inside_matrix)
                    father_node = copy.deepcopy(elem_body2)
                    if hasattr(previous_node, 'body'):
                        previous_node.body = []
                    if hasattr(previous_node, 'name'):
                        previous_node.name = None

                    Before_matrix = modify_Before_matrix_insert_in(node, father_node, individuo.collection_of_nodes,
                                                                       Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix_insert_in(
                        node, father_node, individuo.collection_of_nodes, Inside_matrix)

                    weight, sum_of_differences = calculate_weight(
                        node, individuo.collection_of_nodes, Before_matrix, Inside_matrix, Before_average_matrix, Inside_average_matrix)
                    weight_list.append(weight)
                    sum_of_differences_list.append(sum_of_differences)
                softmax_weights = softmax(weight_list)
                #print(weight_list)
                #print(softmax_weights)
                #if sum(softmax_weights) != 0:
                Choice = choice(Temp_Cells, 1, p=softmax_weights)[0]
                #Choice = Temp_Cells[weight_list.index(max(weight_list))]
                index_of_Choice = Temp_Cells.index(Choice)
                ##para el caso que hay que añadir, hay que poner el if len(elem_body2.body)==0 aqui, y hacer ese caso y en el que no está vacío
                if len(elem_body2.body) == 0:
                    R=0
                else:
                    R = random.randint(1, 1000)
                    R = R / 1000

                if R <= weight_list[index_of_Choice]:
                    elem_body2.body.insert(0, Choice)
                    Temp_Cells.remove(Choice)

                    Before_matrix = modify_Before_matrix(Choice, previous_node, individuo.collection_of_nodes,
                                Before_matrix, Inside_matrix)
                    Inside_matrix = modify_Inside_matrix(Choice, previous_node, individuo.collection_of_nodes,  Inside_matrix)

                    individuo.Before_matrix = Before_matrix
                    individuo.Inside_matrix = Inside_matrix

            for elem_body3 in elem_body2.body:
                weight_list = []
                sum_of_differences_list = []
                if Temp_Cells != []:
                    for node in Temp_Cells:
                        Before_matrix = copy.deepcopy(individuo.Before_matrix)
                        Inside_matrix = copy.deepcopy(individuo.Inside_matrix)
                        previous_node = copy.deepcopy(elem_body3)
                        if hasattr(previous_node, 'body'):
                            previous_node.body = []
                        if hasattr(previous_node, 'name'):
                            previous_node.name = None
                        Before_matrix = modify_Before_matrix(node, previous_node, individuo.collection_of_nodes,
                                                            Before_matrix, Inside_matrix)
                        Inside_matrix = modify_Inside_matrix(
                        node, previous_node, individuo.collection_of_nodes,  Inside_matrix)
                        weight, sum_of_differences = calculate_weight(
                            node, individuo.collection_of_nodes, Before_matrix, Inside_matrix, Before_average_matrix, Inside_average_matrix)
                        weight_list.append(weight)
                        sum_of_differences_list.append(sum_of_differences)
                    softmax_weights = softmax(weight_list)
                    #print(weight_list)
                    #print(softmax_weights)
                    #if sum(softmax_weights) != 0:
                    Choice = choice(Temp_Cells, 1, p=softmax_weights)[0]
                    #Choice=Temp_Cells[weight_list.index(max(weight_list))]

                    index_of_Choice = Temp_Cells.index(Choice)

                    R = random.randint(1, 1000)
                    R = R / 1000

                    if R <= weight_list[index_of_Choice]:
                        elem_body2.body.insert(
                            elem_body2.body.index(elem_body3) + 1, Choice)
                        Temp_Cells.remove(Choice)

                        Before_matrix = modify_Before_matrix(Choice, previous_node, individuo.collection_of_nodes,
                                    Before_matrix, Inside_matrix)
                        Inside_matrix = modify_Inside_matrix(Choice, previous_node, individuo.collection_of_nodes,  Inside_matrix)

                        individuo.Before_matrix = Before_matrix
                        individuo.Inside_matrix = Inside_matrix
    #print("MEAN OF SUMS")
    #print(np.mean(sum_of_differences_list))
    #print(max(sum_of_differences_list))
    individuo.cells=Temp_Cells
    return individuo


def make_first_generation(population,var, expval, methinp, module_name, class_name, function_name, test_name, method_name, atributes, assert_type):


    for individuo in population:

        Cells = make_nodes(var, expval, methinp,
                        module_name, class_name, function_name, test_name, method_name, atributes, assert_type)
        core_nodes=function_core_nodes(module_name)
        cells_copy=copy.deepcopy(Cells)
        individuo.collection_of_nodes =core_nodes+cells_copy

        #print(individuo.collection_of_nodes)
        #for thing in individuo.collection_of_nodes:
        #   print(dump(thing))
        #   print("linea")
        #   print(individuo.collection_of_nodes)
        if not hasattr(individuo.tree, 'body'):
            continue
        individuo.cells=Cells
        ##hacer before y inside matrixes:
        #print(Cells)
        #print(dump(individuo.tree))
        Before_matrix = get_before_matrix(individuo.collection_of_nodes, individuo.tree)##quizá tendría más sentido que hubiera un Cells que se modifica y otro que no
        Inside_matrix = get_inside_matrix(individuo.collection_of_nodes, individuo.tree)##o sea, los dos siendo atributos de individuo
        individuo.Before_matrix=Before_matrix
        individuo.Inside_matrix=Inside_matrix
        individuo= insert_nodes(individuo)

    return population



def mutate_population(population):
    new_population=[]
    for individuo in population:
        new_individuo = copy.deepcopy(individuo)


        if not hasattr(new_individuo.tree, 'body'):
            continue

        new_individuo = insert_nodes(new_individuo)

        if to_source(new_individuo.tree) == to_source(individuo.tree):
            continue
            
        new_population.append(new_individuo)

    return new_population



def filter_population(population):
    arboles_buenos = []


    #Filtro:

    for individuo in population:
        try:
            exec(to_source(individuo.tree), None, globals())
            print("resultado del test: {}".format(resultado.tests_run[0][2]))
            if resultado.tests_run[0][2]==1:
                arboles_buenos.append(individuo)
        except:
            pass

    return arboles_buenos


def calcular_longitud_arbol(population):
    if not type(population) == list:
        population = [population]

    V_contadores = []

    for individuo in population:
        cont = 0

        if not hasattr(individuo.tree, 'body'):
            continue
        for elem_body1 in individuo.tree.body:
            cont += 1

            if not hasattr(elem_body1, 'body'):
                continue
            for elem_body2 in elem_body1.body:
                cont += 1

                if not hasattr(elem_body2, 'body'):
                    continue
                for _ in elem_body2.body:
                    cont += 1
        V_contadores.append(cont)
    return V_contadores


def delete_Pass(population):
    for tree in population:
        for elem_body1 in reversed(tree.body):
            if isinstance(elem_body1, Pass):
                tree.body.remove(elem_body1)

            if not hasattr(elem_body1, 'body'):
                continue

            for elem_body2 in elem_body1.body:
                if isinstance(elem_body2, Pass):
                    elem_body1.body.remove(elem_body2)
    return population
