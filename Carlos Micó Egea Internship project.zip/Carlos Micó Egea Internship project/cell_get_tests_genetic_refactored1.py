from ast import *
from astor import *
import random
import numpy as np
import functions
import itertools
import math
#import modulo_prueba
import copy
from modify_data import format_data
from operations_with_nodes_withML import make_blank_population, make_first_generation, mutate_population, filter_population
from operations_with_nodes_withML import Individual, calcular_longitud_arbol, delete_Pass
#import operations_with_nodes
#from operations_with_nodes import make_blank_population, make_first_generation, mutate_population, filter_population
#from operations_with_nodes import Individual, calcular_longitud_arbol, delete_Pass

import time
'''
start = time.time()
print("hello")
end = time.time()
print(end - start)
'''
def cell_create_tests_genetic(variables=[[None]], expected_value=[[None]], module_name=None, function_name=None, class_name=None, atributes=[None], method_name=None, method_input=[[None]]):
    
    amount_of_trees=300
    

    try:
        test_name = 'test_' + function_name
    except TypeError:
        test_name = 'test_' + method_name

    assert_type = "assertEqual"
    test_number = 1

    #Here the program checks for the format of the parameters "variables" amd "expected_value"
    #it turns them into a list of list if that's not the case already
    [variables, expected_value, method_input] = format_data(variables, expected_value, method_input)
    

    V_final_multivariable=[]
    
    for k in range(0,len(variables)):
        print(variables)

        population=[]
        #while population==[]:
        population = make_blank_population(module_name, amount_of_trees)

        '''
        Data=[variables[k], expected_value[k], method_input[k],
                            module_name, class_name, function_name, test_name, method_name, atributes, assert_type]
        '''
        start = time.time()
        population = make_first_generation(population,variables[k], expected_value[k], method_input[k],
                                                        module_name, class_name, function_name, test_name, method_name, atributes, assert_type)

        end = time.time()
        print(end - start)

        population = filter_population(population)
        #if population==[]:
        #    time.sleep(10)

        

        print("Primera generacion:")
        print(calcular_longitud_arbol(population))
        padres=calcular_longitud_arbol(population)



        #Generaciones a partir de la primera
        amount_of_generations=50

        for i in range(0,amount_of_generations):

            new_population=mutate_population(population)

            new_population=filter_population(new_population)


            
            print("Generacion {}".format(i + 2))
            print("Antiguos:")
            print(len(population))
            print("Nuevos:")
            print(len(new_population))
            population=population+new_population
            print("Longitudes del total:")
            print(calcular_longitud_arbol(population))

        
        print(end - start)


        V=[]
        for individuo in population:
            V.append(individuo)

        

        len_population=len(population)



        Longitudes = calcular_longitud_arbol(V)
        #hijos = calcular_longitud_arbol(V)
        '''
        if len(V)==0:
            return [V, padres, hijos]
        '''

        print("Las longitudes de los padres son: {}".format(padres))
        print("\nLas longitudes de la poblacion final son: {}".format(Longitudes))
        print("El arbol mas grande tiene longitud: {}".format(max(Longitudes)))

        amount_of_best_tests=0
        V_max = []
        real_max = max(Longitudes)
        if real_max!=min(Longitudes):
            for i in reversed(range(0, len(Longitudes))):
                if max(Longitudes) == real_max:
                    max_index = Longitudes.index(max(Longitudes))
                    V_max.append(V[max_index].tree)
                    del V[max_index]
                    del Longitudes[max_index]
                    amount_of_best_tests+=1

        
        #quitar Pass:

        V_max = delete_Pass(V_max)


        #traducir a codigo:
        V_final = []
        for tree in V_max:
            V_final.append(to_source(tree))

        #eliminar repetidos:
        V_final = list(set(V_final))

        print("Hemos generado {} arboles usables y hay {} de longitud maxima ({})".format(len_population, amount_of_best_tests,real_max))

        V_final_multivariable = V_final_multivariable+V_final


    #return [V_final, padres, hijos]
    return V_final_multivariable

