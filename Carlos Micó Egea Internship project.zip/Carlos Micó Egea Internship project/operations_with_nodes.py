from ast import *
from astor import to_source

import random
import copy


class Individual:
    def __init__(self, tree, node_list=None, prob_list=None):
        self.tree = tree
        self.node_list = node_list
        self.prob_list = prob_list


def make_blank_population(module_name, amount_of_trees):
    file = open("hardcoded_part_code.py", 'r')
    code = file.read()  # code of the blank test
    import_node = Import(names=[alias(name=module_name, asname=None)])
    population = []
    for _ in range(0, amount_of_trees):
        individuo = Individual(parse(code))
        # Insert the correct Import in our tree
        individuo.tree.body.insert(0, import_node)
        population.append(individuo)

    return population


def make_nodes(var, expectval, methinp, module_name, class_name, function_name, test_name, method_name, atributes, assert_type):

    var_A = Name(id="A")

    A = FunctionDef(name=test_name,
            args=arguments(args=[arg(arg='self', annotation=None)],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]),
            body=[],
            decorator_list=[],
            returns=None)

    B = Assign(targets=[var_A],
                value=Call(func=Attribute(value=Name(id=module_name), attr=function_name),
                            args=var,
                            keywords=[]))


    C = Expr(
        value=Call(func=Attribute(value=Name(id='self'), attr=assert_type),
                    args=[var_A] + expectval,
                    keywords=[]))

    D=Assign(targets=[var_A],
            value=Call(func=Attribute(value=Name(id=module_name), attr=class_name),
                args=var,
                keywords=[]))

    E=Expr(
            value=Call(func=Attribute(value=var_A, attr=method_name),
                args=methinp,
                keywords=[]))

    F=[]
    for i in range(0, len(atributes)):
        Node = Expr(
            value=Call(func=Attribute(value=Name(id='self'), attr=assert_type),
                    args=[
                    Attribute(value=var_A, attr=atributes[i]), expectval[i]],
                    keywords=[]))
        F.append(Node)
        
    return [A,B,C,D,E,*F]


def insert_nodes(individuo, Temp_Cells):

    for elem_body1 in individuo.tree.body:
        '''
        R=random.randint(1,10)
        if(R>=8):
            Choice = random.choice(Temp_Cells)
            tree.body.insert(len(tree.body)+1, Choice)
            Temp_Cells.remove(Choice)
        '''
        if not hasattr(elem_body1,'body'):
            continue
        for elem_body2 in elem_body1.body:
            R=random.randint(1,10)

            if R>=6 and Temp_Cells!=[]:
                
                Choice = random.choice(Temp_Cells)
                
                elem_body1.body.insert(elem_body1.body.index(elem_body2)+1, Choice)
                Temp_Cells.remove(Choice)
                

            if not hasattr(elem_body2, 'body'):
                continue

            if len(elem_body2.body)==0 and Temp_Cells!=[]:
                Choice = random.choice(Temp_Cells)
                elem_body2.body.insert(0, Choice)
                Temp_Cells.remove(Choice)

            for elem_body3 in elem_body2.body:
                R=random.randint(1,10)

                if R>=4 and Temp_Cells!=[]:
                    Choice = random.choice(Temp_Cells)
                    elem_body2.body.insert(elem_body2.body.index(elem_body3)+1, Choice)
                    Temp_Cells.remove(Choice)
    individuo.node_list=Temp_Cells
    return individuo


def make_first_generation(population,var, expval, methinp, module_name, class_name, function_name, test_name, method_name, atributes, assert_type):


    for individuo in population:

        Cells = make_nodes(var, expval, methinp,
                        module_name, class_name, function_name, test_name, method_name, atributes, assert_type)


        if not hasattr(individuo.tree, 'body'):
            continue

        individuo = insert_nodes(individuo, Cells)

    return population



def mutate_population(population):
    new_population=[]
    for individuo in population:
        new_individuo = copy.deepcopy(individuo)

        Cells = new_individuo.node_list

        if not hasattr(new_individuo.tree, 'body'):
            continue

        new_individuo = insert_nodes(new_individuo, Cells)

        if to_source(new_individuo.tree) == to_source(individuo.tree):
            continue
        new_individuo.node_list = Cells
        new_population.append(new_individuo)

    return new_population



def filter_population(population):
    arboles_buenos = []


    #Filtro:

    for individuo in population:
        try:
            exec(to_source(individuo.tree), None, globals())
            print("resultado del test: {}".format(resultado.tests_run[0][2]))
            if resultado.tests_run[0][2]==1:
                arboles_buenos.append(individuo)
        except:
            pass

    return arboles_buenos


def calcular_longitud_arbol(population):
    if not type(population) == list:
        population = [population]

    V_contadores = []

    for individuo in population:
        cont = 0

        if not hasattr(individuo.tree, 'body'):
            continue
        for elem_body1 in individuo.tree.body:
            cont += 1

            if not hasattr(elem_body1, 'body'):
                continue
            for elem_body2 in elem_body1.body:
                cont += 1

                if not hasattr(elem_body2, 'body'):
                    continue
                for _ in elem_body2.body:
                    cont += 1
        V_contadores.append(cont)
    return V_contadores


def delete_Pass(population):
    for tree in population:
        for elem_body1 in reversed(tree.body):
            if isinstance(elem_body1, Pass):
                tree.body.remove(elem_body1)

            if not hasattr(elem_body1, 'body'):
                continue

            for elem_body2 in elem_body1.body:
                if isinstance(elem_body2, Pass):
                    elem_body1.body.remove(elem_body2)
    return population