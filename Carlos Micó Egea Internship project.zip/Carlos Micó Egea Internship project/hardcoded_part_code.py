import unittest


class TestMethods(unittest.TestCase):
	pass

suite = unittest.TestLoader().loadTestsFromTestCase(TestMethods)
resultado=unittest.TextTestRunner(verbosity=2).run(suite)



