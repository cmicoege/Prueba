import numpy as np
from ast import *
import copy
#node_list=[1,2,3,4]
from astor import *
import math
import time
'''
def search_node(node, tree):
    FOUND=False

    if node in tree.body:
        FOUND = True
        return FOUND

    for element in tree.body:

        if not hasattr(element, 'body'):
            continue
        if node in element.body:
            FOUND = True
            return FOUND

        for element2 in element.body:

            if not hasattr(element2, 'body'):
                continue
            if node in element2.body:
                FOUND = True
                return FOUND

            for element3 in element2.body:

                if not hasattr(element3)
                if node in element3.body:
                    FOUND = True
                    return FOUND

    return FOUND
'''

'''
def nodes_containing(node, tree):
    #rest_of_nodes=[element for element in node_list if element!=node]
    INSIDE_list=[]
    for other_node in node_list:
        if other_node!=node:
            FOUND=(other_node, tree)
            if FOUND:
                if hasattr(other_node,'body'):
                    if node in other_node.body:##mal, body es []
                        INSIDE_list.append(1)
                else:
                    INSIDE_list.append(0)
            else:
                INSIDE_list.append('X')
        else:
            INSIDE_list.append('N')
    return INSIDE_list
'''
'''
def nodes_after(node, tree):

    BEFORE_list = []
    for other_node in node_list:
        if other_node != node:
            [node_order, FOUND] = search_node(other_node, tree)
            print(other_node)
            print("found:")
            print(FOUND)
            other_node_copy=copy.deepcopy(other_node)
            if hasattr(other_node_copy, 'name'):
                other_node_copy.name=None
            print(dump(other_node_copy))
            FOUND_copy = []
            if FOUND:
                for element in FOUND:
                    element_copy=copy.deepcopy(element)
                    if hasattr(element_copy,'body'):
                        element_copy.body=[]
                    if hasattr(element_copy,'name'):
                        element_copy.name=None
                    FOUND_copy.append(dump(element_copy))
                print("found_copy:")
                print(FOUND_copy)
                print(dump(other_node_copy) in FOUND_copy)


                print("blibliblibli")
                print(FOUND_copy)
                node_copy=copy.deepcopy(node)
                if hasattr(node_copy,'name'):
                    node_copy.name=None
                print(dump(node_copy))
                print(dump(other_node))


                if dump(node_copy) in FOUND_copy and FOUND_copy.index(dump(node_copy)) < FOUND_copy.index(dump(other_node_copy)):
                    print("HOLAHOLAHOLAHOLAHOLAHOLAHOLAHOLAHOLA")
                    BEFORE_list.append(1)
                else:
                    BEFORE_list.append(0)
            else:
                BEFORE_list.append('X')
        else:
            BEFORE_list.append(None)
    return BEFORE_list
'''
def nodes_after2(node, node_list, tree): #node before otherNode
    BEFORE_list=[]
    node_order, node_FOUND=search_node(node, tree)
    if node_FOUND:
        for otherNode in node_list:  #### node_list deberia pasarse en todas las funciones (creo, o al menos en esta)
            if otherNode != node:
                otherNode_order, otherNode_FOUND=search_node(otherNode,tree)
                if otherNode_FOUND:
                    if otherNode_order<node_order:
                        BEFORE_list.append(0)
                    else: 
                        BEFORE_list.append(1)
                else:
                    BEFORE_list.append('X')
            else:
                BEFORE_list.append('N')
    else:
        BEFORE_list = ['X' for _ in node_list]
    
    return BEFORE_list


def nodes_containing2(node, node_list, tree): #node inside otherNode
    INSIDE_list=[] 
    _,node_FOUND = search_node(node,tree)
    if node_FOUND:
        for otherNode in node_list:
            if otherNode != node:
                _,otherNode_FOUND = search_node(otherNode, tree)
                if otherNode_FOUND:
                    _,node_Inside_otherNode=search_node(node,otherNode_FOUND)
                    if node_Inside_otherNode:
                        INSIDE_list.append(1)
                    else:
                        INSIDE_list.append(0)
                else:
                    INSIDE_list.append('X')

            else:
                INSIDE_list.append('N')
    else:
        INSIDE_list=['X' for _ in node_list]
    
    return INSIDE_list


'''

def list_containing(node, tree):
    list_containing_node=[]

    node_copy=copy.deepcopy(node)
    if hasattr(node_copy,'name'):
        node_copy.name=None
    print("dentro")
    for element in tree.body:
        Element_copy=copy.deepcopy(element)
        if hasattr(Element_copy,'body'):
            Element_copy.body=[]
        if hasattr(Element_copy,'name'):
            Element_copy.name=None
        #print("####################")
        #print(dump(Element_copy))
        #print(dump(node_copy))
        if dump(Element_copy) == dump(node):
            print("IGUALES!")
            list_containing_node = tree.body
            print(list_containing_node)
            return list_containing_node
        else:
            print(dump(Element_copy))
            print(dump(node_copy))


        if not hasattr(element, 'body'):
            continue

        for element2 in element.body:

            Element2_copy=copy.deepcopy(element2)
            if hasattr(Element2_copy, 'body'):
                Element2_copy.body = []
            if hasattr(Element2_copy, 'name'):
                Element2_copy.name = None
            #print("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            #print(dump(Element2_copy))
            #print(dump(node_copy))
            if dump(Element2_copy) == dump(node_copy):
                print("IGUALES!")
                list_containing_node=element.body
                print(list_containing_node)
                return list_containing_node
            else:
                print(dump(Element2_copy))
                print(dump(node_copy))

            if not hasattr(element2, 'body'):
                continue

            for element3 in element2.body:
                Element3_copy = copy.deepcopy(element3)
                if hasattr(Element3_copy, 'body'):
                    Element3_copy.body = []
                if hasattr(Element3_copy, 'name'):
                    Element3_copy.name = None
                #print("++++++++++++++++++++++++++++++++")
                #print(dump(Element3_copy))
                #print(dump(node_copy))

                if dump(Element3_copy) == dump(node_copy):
                    print("IGUALES!")
                    list_containing_node = element2.body
                    print(list_containing_node)
                    return list_containing_node
                else:
                    print(dump(Element3_copy))
                    print(dump(node_copy))
    print("fuera")
    return list_containing_node
'''


def search_node(node, tree):
    node_order = 1
    #node_deepness = None #de momento solo el otro 
    node_from_tree=None

    node_copy = copy.deepcopy(node)
    if hasattr(node_copy, 'name'):
        node_copy.name = None
    #print("dentro")

    if not hasattr(tree, 'body'):
        #continue #este continue aqui no ejecuta, pero en el programa bien hecho deberia haber un continue porque creo que
        #el bucle que se mueve entre los arboles disponibles deberia estar aqui dentro, o al menos en otra funcion (y el continue con ese bucle)
        #print("tree no tiene body")
        return (node_order, node_from_tree)
    else:
        tree_copy=copy.deepcopy(tree)
        tree_copy.body=[]

    if dump(tree_copy)==dump(node_copy):
        #print("IGUALES!")
        node_from_tree=tree
        return (node_order, node_from_tree)
    #else:
        #print(dump(tree_copy))
        #print(dump(node_copy))
    for element in tree.body:
        Element_copy = copy.deepcopy(element)
        if hasattr(Element_copy, 'body'):
            Element_copy.body = []
        if hasattr(Element_copy, 'name'):
            Element_copy.name = None
        #print("####################")
        #print(dump(Element_copy))
        #print(dump(node_copy))
        #if type(node_copy)==ClassDef and type(Element_copy)==ClassDef:
        #    str1=dump(node_copy)
        #    str2=dump(Element_copy)
        #    print(str1.find(str2))
        node_order += 1
        if dump(Element_copy) == dump(node_copy):
            #print("IGUALES!")
            node_from_tree = element
            return (node_order, node_from_tree)
        #else:
            #print(dump(Element_copy))
            #print(dump(node_copy))

        if not hasattr(element, 'body'):
            continue

        for element2 in element.body:

            Element2_copy = copy.deepcopy(element2)
            if hasattr(Element2_copy, 'body'):
                Element2_copy.body = []
            if hasattr(Element2_copy, 'name'):
                Element2_copy.name = None
            #print("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            #print(dump(Element2_copy))
            #print(dump(node_copy))
            node_order += 1
            if dump(Element2_copy) == dump(node_copy):
                #print("IGUALES!")
                node_from_tree = element2
                return (node_order, node_from_tree)
            #else:
                #print(dump(Element2_copy))
                #print(dump(node_copy))

            if not hasattr(element2, 'body'):
                continue

            for element3 in element2.body:
                Element3_copy = copy.deepcopy(element3)
                if hasattr(Element3_copy, 'body'):
                    Element3_copy.body = []
                if hasattr(Element3_copy, 'name'):
                    Element3_copy.name = None
                #print("++++++++++++++++++++++++++++++++")
                #print(dump(Element3_copy))
                #print(dump(node_copy))
                node_order += 1
                if dump(Element3_copy) == dump(node_copy):
                    #print("IGUALES!")
                    node_from_tree = element3
                    return (node_order, node_from_tree)
                #else:
                    #print(dump(Element3_copy))
                    #print(dump(node_copy))
    #print("fuera")
    return (node_order, node_from_tree)


def sum_matrixes(M1, M2):
    ###el son listas de listas porque una matriz numpy no puede tener datos de distintos tipos, y una lista de listas sí puede
    n = len(M1)
    try:
        m = len(M1[0])
        if np.asarray(M1).shape == np.asarray(M2).shape:
            suma = np.zeros((n, m)).tolist()
            for i in range(n):
                for j in range(m):
                    try:
                        if(M1[i][j] == 'X' and M2[i][j] == 'X'):
                            suma[i][j] = 'X'
                        elif M1[i][j] == 'N' and M2[i][j] == 'N':
                            suma[i][j] = 'N'
                        else:
                            suma[i][j] = M1[i][j] + M2[i][j]
                    except:
                        if M1[i][j] == 'X' and M2[i][j] != 'X':
                            suma[i][j] = M2[i][j]
                        if M1[i][j] != 'X' and M2[i][j] == 'X':
                            suma[i][j] = M1[i][j]

        else:
            print("{} y {}".format(np.asarray(M1).shape, np.asarray(M2).shape))
            print("The matrixes' sizes don't match.")
            suma = None
    except TypeError:
        if np.asarray(M1).shape == np.asarray(M2).shape:
            suma = np.zeros(n).tolist()
            for i in range(n):
                    try:
                        if(M1[i] == 'X' and M2[i] == 'X'):
                            suma[i] = 'X'
                        elif M1[i] == 'N' and M2[i] == 'N':
                            suma[i] = 'N'
                        else:
                            suma[i] = M1[i] + M2[i]
                    except:
                        if M1[i] == 'X' and M2[i] != 'X':
                            suma[i] = M2[i]
                        if M1[i] != 'X' and M2[i] == 'X':
                            suma[i] = M1[i]

        else:
            print("{} y {}".format(np.asarray(M1).shape, np.asarray(M2).shape))
            print("The matrixes' sizes don't match.")
            suma = None
    return suma


def unsigned_difference_matrixes(M1, M2):
    ###el son listas de listas porque una matriz numpy no puede tener datos de distintos tipos, y una lista de listas sí puede
    n = len(M1)
    try:
        m = len(M1[0])
        if np.asarray(M1).shape == np.asarray(M2).shape:
            resta = np.zeros((n, m)).tolist()
            for i in range(n):
                for j in range(m):
                    try:
                        if(M1[i][j] == 'X' and M2[i][j] == 'X'):
                            resta[i][j] = 'X'
                        elif M1[i][j] == 'N' and M2[i][j] == 'N':
                            resta[i][j] = 'N'
                        else:
                            resta[i][j] = np.absolute(M1[i][j] - M2[i][j])
                    except:
                        if M1[i][j] == 'X' and M2[i][j] != 'X':
                            #resta[i][j] = 'X'  #cambio para dar más importancia a que falte un nodo que suele estar
                            resta[i][j] = M2[i][j]
                        if M1[i][j] != 'X' and M2[i][j] == 'X':
                            #resta[i][j] = 'X'
                            resta[i][j] = M1[i][j]
        else:
            print("{} y {}".format(np.asarray(M1).shape, np.asarray(M2).shape))
            print("The matrixes' sizes don't match.")
            resta = None
    except TypeError:
        if np.asarray(M1).shape == np.asarray(M2).shape:
            resta = np.zeros(n).tolist()
            for i in range(n):
                    try:
                        if(M1[i] == 'X' and M2[i] == 'X'):
                            resta[i] = 'X'
                        elif M1[i] == 'N' and M2[i] == 'N':
                            resta[i] = 'N'
                        else:
                            resta[i] = np.absolute(M1[i] - M2[i])
                    except:
                        if M1[i] == 'X' and M2[i] != 'X': 
                            #resta[i] = 'X' #cambio para dar más importancia a que falte un nodo que suele estar
                            resta[i] = M2[i]
                        if M1[i] != 'X' and M2[i] == 'X':
                            #resta[i] = 'X'
                            resta[i] = M1[i]
        else:
            print("{} y {}".format(np.asarray(M1).shape, np.asarray(M2).shape))
            print("The matrixes' sizes don't match.")
            resta = None
    return resta
def count_occurrence(List_of_matrixes):
    n = len(List_of_matrixes[0])
    occurrence_matrix = np.zeros((n,n)).tolist()

    for i in range(n):
        for j in range(n):
            count=0
            for matrix in List_of_matrixes:
                if matrix[i][j] != 'N' and matrix[i][j] != 'X':
                    count+=1
            occurrence_matrix[i][j]=count
    return occurrence_matrix

def elementwise_inverse(matrix):
    n=len(matrix)
    m=len(matrix[0])
    pseudoinverse=np.zeros((n,m)).tolist()
    for i in range(n):
        for j in range(m):
            if matrix[i][j]!=0:
                pseudoinverse[i][j] = 1 / matrix[i][j]
            else:
                pseudoinverse[i][j] = 1
    return pseudoinverse

def elementwise_multiplication(M1,M2):
    n = len(M1)
    m=len(M1[0])
    if np.asarray(M1).shape == np.asarray(M2).shape:
        multiplication = np.zeros((n,m)).tolist()
        for i in range(n):
            for j in range(m):
                if(M1[i][j] == 'X' and M2[i][j] == 'X'):
                    multiplication[i][j]='X'
                elif M1[i][j] == 'N' and M2[i][j] == 'N':
                    multiplication[i][j]='N'
                else:
                    multiplication[i][j]=M1[i][j] * M2[i][j]

    else:
        print("{} y {}".format(np.asarray(M1).shape, np.asarray(M2).shape))
        print("The matrixes' sizes don't match.")
        multiplication = None

    return multiplication

def average_matrix_of(List_of_matrixes):
    occurrence_matrix=count_occurrence(List_of_matrixes)
    multipliers = elementwise_inverse(occurrence_matrix)

    total=List_of_matrixes[0]

    for i in range(1,len(List_of_matrixes)):
        total=sum_matrixes(total,List_of_matrixes[i])

    total=elementwise_multiplication(multipliers,total)
    return total

def get_column(Matrix, index):
    n=len(Matrix)
    Column=[]
    try:
        m=len(Matrix[0])
        for i in range(n):
            Column.append(Matrix[i][index])
    except TypeError:
        Column.append(Matrix[index])
    
    return Column

def compare_with_average_matrix(node, M1, node_list, Average_matrix):
    i=get_index(node, node_list)

    Row=unsigned_difference_matrixes(M1[i],Average_matrix[i])

    ColumnM1=get_column(M1,i)

    ColumnAverage_matrix=get_column(Average_matrix,i)

    Column=unsigned_difference_matrixes(ColumnM1,ColumnAverage_matrix)

    return Row+Column


def sum_elements_of_list(list_of_differences):
    suma = 0
    for element in list_of_differences:
        try:
            suma += element
        except TypeError:
            pass
    return suma








def calculate_weight(node, node_list,Before,Inside,Before_Average_matrix, Inside_Average_matrix):
    #esta función tiene que tener algo mal en algún lado. las pruebas están en salida_python.txt

    differencesBefore=compare_with_average_matrix(node,Before, node_list, Before_Average_matrix)
    differencesInside=compare_with_average_matrix(node,Inside, node_list, Inside_Average_matrix)
    sum_of_differences=sum_elements_of_list(differencesBefore+differencesInside)

    i=get_index(node, node_list)
    #print(i)
    #print(Before_Average_matrix[i])
    amount_of_nodes_present=0
    for element in Before_Average_matrix[0]:#las dos matrices promedio tienen la misma cantidad de nodos, los contamos en cualquiera de las dos
        if element!='X':
            amount_of_nodes_present+=1#este bucle tiene mala pinta. si el nodo no está en average matrix, esto vale cero. 
            #y entonces el peso vale cero. el misterio es por qué sum_of_differences en esos casos no es cero
            #era porque si solo uno de los dos es X, sí que aporta algo a sum_of_differences
        #print(amount_of_nodes_present)
    if amount_of_nodes_present!=0:
        #weight=1
        #if sum_of_differences<=3 and sum_of_differences>=0:
        #    weight= -sum_of_differences*(1/20) + 1
        #else:
        #    weight=0
        #if sum_of_differences<=12:
        #    a=1/(amount_of_nodes_present*amount_of_nodes_present)
        #    weight=-a*sum_of_differences*sum_of_differences+1 #parabola
        #    #print("a")
        #    #print(a)
        #else:
        #    weight=0
        #weight=(2*amount_of_nodes_present-sum_of_differences)/(2*amount_of_nodes_present) # lineal, funciona pero quiero mejorar el resultado
        #weight=math.pow(1.1,-sum_of_differences) #exponencial, no funciona
        weight=1/(1+math.exp(sum_of_differences-(1/2)*amount_of_nodes_present)) #sigmoide, va bien con pow(2,asd) y exp(asd)
        #pero creo que la exponencial hace que tarde más
        #weight=0.7

        #print("amount_of_nodes_present")
        #print(amount_of_nodes_present)
        #print("sum_of_differences")
        #print(sum_of_differences)
        #print("weight")
        #print(weight)
        '''
        if sum_of_differences<=6:
            print("indice:")
            print(i)
            print(np.asarray(Before).view())
            print(np.asarray(Before_Average_matrix).view())
            print(differencesBefore)
            print(np.asarray(Inside).view())
            print(np.asarray(Inside_Average_matrix).view())
            print(differencesInside)
            time.sleep(10)
        '''
    else:
        '''print("es cero")
        print(sum_of_differences)
        print(amount_of_nodes_present)
        print("índice: {}".format(i))
        print("before")
        print(np.asarray(Before))
        print(np.asarray(Before_Average_matrix))
        print("inside")
        print(np.asarray(Inside))
        print(np.asarray(Inside_Average_matrix))'''
        weight=0
    
    '''if sum_of_differences==0:
        print("índice: {}".format(i))
        print(sum_of_differences)
        print(amount_of_nodes_present)
        print("before")
        print(np.asarray(Before))
        print(np.asarray(Before_Average_matrix))
        print("inside")
        print(np.asarray(Inside))
        print(np.asarray(Inside_Average_matrix))'''
    return weight, sum_of_differences
    
        
def get_before_matrix(node_list, tree):
    Before_matrix = []

    for node in node_list:
        BEFORE_list = nodes_after2(node, node_list, tree)
        Before_matrix.append(BEFORE_list)
    return Before_matrix

def get_inside_matrix(node_list, tree):
    Inside_matrix=[]

    for node in node_list:
        INSIDE_list=nodes_containing2(node, node_list, tree)
        Inside_matrix.append(INSIDE_list)
    return Inside_matrix

def save_matrix(matrix, filename):
    f = open(filename, 'w')
    for row in matrix:
        for i in range(len(row)):
            f.write(str(row[i]))
            if i == len(row) - 1:
                f.write('\n')
            else:
                f.write(',')
    f.close()


def read_matrix(filename):
    f = open(filename, 'r')
    matrix = []
    for line in f:
        row = []
        for element in line.split(','):
            try:
                row.append(int(element))
            except ValueError:
                if element.endswith('\n'):
                    element=element[:-1]
                row.append(element)
        matrix.append(row)
    f.close()
    return matrix


def get_index(node, node_list):
    index = 0
    node_copy = copy.deepcopy(node)
    if hasattr(node_copy, 'name'):
        node_copy.name = None
    if hasattr(node_copy, 'body'):
        node_copy.body = []

    for element in node_list:
        Element_copy = copy.deepcopy(element)
        if hasattr(Element_copy, 'name'):
            Element_copy.name = None
        
        if to_source(Element_copy) == to_source(node_copy):
            return index
        index += 1
        if index==len(node_list):
            raise IndexError
    return index


def modify_Before_matrix(new_node, previous_node, node_list, Before_matrix, Inside_matrix): #modifica la matriz usando el nodo nuevo 
    previous_index=get_index(previous_node, node_list) #y uno previo
    new_index=get_index(new_node, node_list)
    for i in range(len(node_list)):
        if i!=new_index:

            if Before_matrix[previous_index][i]=='N':
                Before_matrix[new_index][i]=0

            if Before_matrix[i][previous_index]=='N':
                Before_matrix[i][new_index]=1


            if Before_matrix[previous_index][i]=='X':
                Before_matrix[new_index][i]='X'
                    

            if Before_matrix[i][previous_index]=='X':
                Before_matrix[i][new_index]='X'

            if Before_matrix[previous_index][i] == 0: #previous_node no delante de I => new_node no delante de I, siempre
                Before_matrix[new_index][i] = 0# =Before_matrix[previous_index][i]
                
            if Before_matrix[i][previous_index] == 0: #I no delante de previous_node => I podria estar delante de new_node o no
                if Inside_matrix[i][previous_index] == 1:#dependiendo de si I es hijo de previous_node o no
                    Before_matrix[i][new_index] = 1
                elif Inside_matrix[i][previous_index] == 0:
                    Before_matrix[i][new_index] = 0


            if Before_matrix[previous_index][i] == 1:#previous_node delante de I => new_node podria estar delante de I o no
                if Inside_matrix[i][previous_index] == 1:#dependiendo de si I es hijo de previous_node o no
                    Before_matrix[new_index][i] = 0
                elif Inside_matrix[i][previous_index] == 0:
                    Before_matrix[new_index][i] = 1

                
            if Before_matrix[i][previous_index] == 1:#I delante de previous_node => I delante de new_node, siempre
                Before_matrix[i][new_index] = 1# =Before_matrix[previous_index][i]


        else:
            Before_matrix[new_index][new_index]='N'


    return Before_matrix

def modify_Inside_matrix(new_node, previous_node, node_list,  Inside_matrix): #modifica la matriz usando el nodo nuevo y uno previo
    previous_index = get_index(previous_node, node_list)
    new_index = get_index(new_node, node_list)
    for i in range(len(node_list)):
        if i!=new_index:
            if Inside_matrix[previous_index][i] == 'N':
                Inside_matrix[new_index][i] = 0
            if Inside_matrix[i][previous_index] == 'N':
                Inside_matrix[i][new_index] = 0

            if Inside_matrix[previous_index][i]==0 or Inside_matrix[previous_index][i]==1:
                Inside_matrix[new_index][i]=Inside_matrix[previous_index][i]


            if Inside_matrix[previous_index][i] == 'X':
                Inside_matrix[new_index][i] = 'X'
            #Inside_matrix[i][new_index] = 0 creo que no hacia falta, debe de ser de probar cosas
            if Inside_matrix[i][previous_index] == 'X':
                Inside_matrix[i][new_index] = 'X'

            if Inside_matrix[i][previous_index]==0 or Inside_matrix[i][previous_index] == 1 :
                Inside_matrix[i][new_index] = 0

            
        else:
            Inside_matrix[new_index][new_index] = 'N'
        
    return Inside_matrix



def modify_Before_matrix_insert_in(new_node, father_node, node_list, Before_matrix, Inside_matrix): #modifica la matriz usando el
    father_index = get_index(father_node, node_list) #nodo nuevo y el nodo padre
    new_index = get_index(new_node, node_list)
    for i in range(len(node_list)):
        if i != new_index:
            if Before_matrix[father_index][i]=='N':
                Before_matrix[new_index][i]=0

            if Before_matrix[i][father_index]=='N':
                Before_matrix[i][new_index]=1


            if Before_matrix[father_index][i]=='X':
                Before_matrix[new_index][i]='X'
                    
            if Before_matrix[i][father_index] == 'X':
                Before_matrix[i][new_index] = 'X'

            # father_node no delante de I => new_node no delante de I, siempre
            if Before_matrix[father_index][i] == 0:
                Before_matrix[new_index][i] = 0

            # I no delante de father_node => I no delante de new_node siempre
            if Before_matrix[i][father_index] == 0:
                Before_matrix[i][new_index] = 0

            # father_node delante de I => new_node delante de I siempre
            if Before_matrix[father_index][i] == 1:
                Before_matrix[new_index][i] = 1

            # I delante de father_node => I delante de new_node, siempre
            if Before_matrix[i][father_index] == 1:
                Before_matrix[i][new_index] = 1

        else:
            Before_matrix[new_index][new_index] = 'N'
    '''print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
    print(father_index)
    print(new_index)
    if new_index==12 or new_index==13:
        print(dump(new_node))
        print(dump(father_node))'''
    return Before_matrix

def modify_Inside_matrix_insert_in(new_node, father_node, node_list, Inside_matrix):#modifica la matriz
    father_index = get_index(father_node, node_list) #nodo nuevo y el nodo padre
    new_index = get_index(new_node, node_list)
    for i in range(len(node_list)):
        if i!=new_index:
            if Inside_matrix[father_index][i] == 'N':
                Inside_matrix[new_index][i] = 1
            if Inside_matrix[i][father_index] == 'N':
                Inside_matrix[i][new_index] = 0

            if Inside_matrix[father_index][i]==0 or Inside_matrix[father_index][i]==1:
                Inside_matrix[new_index][i]=Inside_matrix[father_index][i]

            if Inside_matrix[i][father_index]==0 or Inside_matrix[i][father_index]==1: #da igual que i sea hijo de father_node o no,,
                Inside_matrix[i][new_index] = 0 #porque seguro que no es hijo de new_node



            if Inside_matrix[father_index][i] == 'X':
                Inside_matrix[new_index][i] = 'X'
                
            if Inside_matrix[i][father_index] == 'X':
                Inside_matrix[i][new_index] = 'X'
            
        else:
            Inside_matrix[new_index][new_index] = 'N'
        
    return Inside_matrix


'''

def modify_Before_matrix_insert_first_node_in(new_node, father_node, node_list, Before_matrix, Inside_matrix): #modifica la matriz usando el
    father_index = get_index(father_node, node_list) #nodo nuevo y el nodo padre, teniendo en cuenta que es el primer hijo
    new_index = get_index(new_node, node_list)
    for i in range(len(node_list)):
        if i != new_index:
            if Before_matrix[father_index][i]=='N':
                Before_matrix[new_index][i]=0

            if Before_matrix[i][father_index]=='N':
                Before_matrix[i][new_index]=1


            if Before_matrix[father_index][i]=='X':
                Before_matrix[new_index][i]='X'
                    
            if Before_matrix[i][father_index] == 'X':
                Before_matrix[i][new_index] = 'X'

            # father_node no delante de I => new_node no delante de I, siempre
            if Before_matrix[father_index][i] == 0:
                Before_matrix[new_index][i] = 0

            # I no delante de father_node => I no delante de new_node siempre
            if Before_matrix[i][father_index] == 0:
                Before_matrix[i][new_index] = 0

            # father_node delante de I => new_node delante de I siempre
            if Before_matrix[father_index][i] == 1:
                Before_matrix[new_index][i] = 1

            # I delante de father_node => I delante de new_node, siempre
            if Before_matrix[i][father_index] == 1:
                Before_matrix[i][new_index] = 1

        else:
            Before_matrix[new_index][new_index] = 'N'

    return Before_matrix


def modify_Inside_matrix_insert_first_node_in(new_node, father_node, node_list, Inside_matrix):#modifica la matriz
    father_index = get_index(father_node, node_list) #nodo nuevo y el nodo padre, teniendo en cuenta que es el primer hijo
    new_index = get_index(new_node, node_list)
    for i in range(len(node_list)):
        if i!=new_index:
            if Inside_matrix[father_index][i] == 'N':
                Inside_matrix[new_index][i] = 1
            if Inside_matrix[i][father_index] == 'N':
                Inside_matrix[i][new_index] = 0

            if Inside_matrix[father_index][i]==0 or Inside_matrix[father_index][i]==1:
                Inside_matrix[new_index][i]=Inside_matrix[father_index][i]

            if Inside_matrix[i][father_index]==0 or Inside_matrix[i][father_index]==1: #da igual que i sea hijo de father_node o no,,
                Inside_matrix[i][new_index] = 0 #porque seguro que no es hijo de new_node



            if Inside_matrix[father_index][i] == 'X':
                Inside_matrix[new_index][i] = 'X'
                
            if Inside_matrix[i][father_index] == 'X':
                Inside_matrix[i][new_index] = 'X'


            
        else:
            Inside_matrix[new_index][new_index] = 'N'
        
    return Inside_matrix
'''

############################ V
'''

sample = open("Tienda_vender_test1.py", 'r')
code = sample.read()
sample = [parse(code)]
#print(dump(parse(code)))
var_A = Name(id="A")

#para la primera version con un sample de muchos tests necesitaré poner las variables de cada uno

#test1 = open("Tienda_vender_test1.py", 'r')
#code1 = test1.read()
#test2 = open("resta_tests1_1.py", 'r')
#code2 = test2.read()

#sample = [parse(code1), parse(code2)]



function_name=None
module_name = "modulo_prueba"
class_name = "Tienda"
atributes = ["ganancias", "stock"]
method_name = "vender"


var = [[Num(200), Num(20)]]
methinp = [[Num(100), Num(15)]]
expectval = [[Num(300), Num(5)]]

######################LINEA PROVISIONAL(x3):
expectval=expectval[0]
var=var[0]
methinp=methinp[0]



#resta:

#module_name = "modulo_prueba"
function_name = "resta"


#var = [[Num(10), Num(5)]]
#expectval = [[Num(5)]]

#class_name = None
#atributes = [None]
#method_name = None
#methinp = [[None]]



try:
    test_name = 'test_' + function_name
except TypeError:
    test_name = 'test_' + method_name

assert_type = "assertEqual"

M=Module(body=[])

I1=Import(names=[alias(name='modulo_prueba', asname=None)])

I2 = Import(names=[alias(name='unittest', asname=None)])

Class_node = ClassDef(name='TestMethods',
            bases=[Attribute(value=Name(id='unittest'), attr='TestCase')],
            keywords=[],
            body=[],
            decorator_list=[])

test_things1=Assign(targets=[Name(id='suite')],
            value=Call(
                func=Attribute(
                    value=Call(func=Attribute(value=Name(id='unittest'), attr='TestLoader'), args=[], keywords=[]),
                    attr='loadTestsFromTestCase'),
                args=[Name(id='TestMethods')],
                keywords=[]))

test_things2=Assign(targets=[Name(id='resultado')],
            value=Call(
                func=Attribute(
                    value=Call(func=Attribute(value=Name(id='unittest'), attr='TextTestRunner'),
                        args=[],
                        keywords=[keyword(arg='verbosity', value=Num(n=2))]),
                    attr='run'),
                args=[Name(id='suite')],
                keywords=[]))
Pass_node = Pass()
A = FunctionDef(name=test_name,
                args=arguments(args=[arg(arg='self', annotation=None)],
                               vararg=None,
                               kwonlyargs=[],
                               kw_defaults=[],
                               kwarg=None,
                               defaults=[]),
                body=[],
                decorator_list=[],
                returns=None)

B = Assign(targets=[var_A],
           value=Call(func=Attribute(value=Name(id=module_name), attr=function_name),
                      args=var,
                      keywords=[]))

C = Expr(
    value=Call(func=Attribute(value=Name(id='self'), attr=assert_type),
               args=[var_A] + expectval,
               keywords=[]))

D = Assign(targets=[var_A],
           value=Call(func=Attribute(value=Name(id=module_name), attr=class_name),
                      args=var,
                      keywords=[]))

E = Expr(
    value=Call(func=Attribute(value=var_A, attr=method_name),
               args=methinp,
               keywords=[]))

F = []


for i in range(0, len(atributes)):
    Node = Expr(
        value=Call(func=Attribute(value=Name(id='self'), attr=assert_type),
                   args=[
            Attribute(value=var_A, attr=atributes[i]), expectval[i]],
            keywords=[]))
    F.append(Node)

node_list = [M, I1, I2, Class_node, test_things1, test_things2, Pass_node, A, B, C, D, E, *F]



Matrix_list_Before=[]
Matrix_list_Inside=[]
for tree in sample:
    Inside_matrix = []
    Before_matrix = []

    for node in node_list:
        print("NODE{}".format(node_list.index(node)))
        #print(dump(node))
        
        #FOUND = search_node(node, tree)
        
        #if FOUND:
        #INSIDE_list = nodes_containing(node, tree)
        BEFORE_list = nodes_after2(node, node_list, tree)
        #else:
        #    print(FOUND)
        #    #INSIDE_list = ['X' for _ in node_list]
        #    BEFORE_list = ['X' for _ in node_list]
        print("before list:")
        print(BEFORE_list)

        INSIDE_list = nodes_containing2(node, node_list,tree)


        order, thing = search_node(node, tree)
        
        
        #print("order:")
        #print(order)
        #print(thing)
        #print("node:")
        #print(node)
        #print("list:")
        #print(thing)
        
        Inside_matrix.append(INSIDE_list)
        Before_matrix.append(BEFORE_list)

    print("before matrix:")
    print(Before_matrix)
    save_matrix(Before_matrix, 'BeforeAverageMatrix.txt')
    
    print(np.asarray(Before_matrix).view())


    print("inside matrix:")
    print(Inside_matrix)
    save_matrix(Inside_matrix, 'InsideAverageMatrix.txt')

    print(np.asarray(Inside_matrix).view())
    save_matrix(Inside_matrix,"input.txt")
    new_matrix=read_matrix("input.txt")
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    print(np.asarray(Inside_matrix).view())
    save_matrix(new_matrix,'new_matrix.txt')

    blablasuma = sum_matrixes(Inside_matrix, Before_matrix)
    print(np.asarray(blablasuma).view())



    bleble=count_occurrence([Inside_matrix])
    print(np.asarray(bleble).view())
    

    blibli=count_occurrence([Inside_matrix,Before_matrix])
    print(np.asarray(blibli).view())
    


    Matrix_list_Before.append(Before_matrix)
    Matrix_list_Inside.append(Inside_matrix)
'''
########################## ^



'''

average2=average_matrix_of([Inside_matrix,Inside_matrix, Inside_matrix,Inside_matrix,Before_matrix])
print(np.asarray(average2))




average1=average_matrix_of([Inside_matrix,Before_matrix, Before_matrix, Before_matrix,Before_matrix])
print(np.asarray(average1))


'''

#########before matrix ya funciona bien!!! (pero solo compara nodos hermanos, no vecinos. Creo que querría contar vecinos también)
####arreglado, ya mira todos.
'''
[[None 'X' 'X' 0 0 0 0]
 ['X' 'X' 'X' 'X' 'X' 'X' 'X']
 ['X' 'X' 'X' 'X' 'X' 'X' 'X']
 [0 'X' 'X' None 1 1 1]
 [0 'X' 'X' 0 None 1 1]
 [0 'X' 'X' 0 0 None 0]
 [0 'X' 'X' 0 0 1 None]]
 '''







#con Module, ClassDef y todo. Ya funcionan las dos matrices.
'''
[[None 1 1 1 1 1 1 'X' 'X' 1 1 1 1]
 [0 None 1 1 1 1 1 'X' 'X' 1 1 1 1]
 [0 0 None 1 1 1 1 'X' 'X' 1 1 1 1]
 [0 0 0 None 1 1 1 'X' 'X' 1 1 1 1]
 [0 0 0 0 None 1 0 'X' 'X' 0 0 0 0]
 [0 0 0 0 0 None 0 'X' 'X' 0 0 0 0]
 [0 0 0 0 1 1 None 'X' 'X' 1 1 1 1]
 ['X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X']
 ['X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X']
 [0 0 0 0 1 1 0 'X' 'X' None 1 1 1]
 [0 0 0 0 1 1 0 'X' 'X' 0 None 1 1]
 [0 0 0 0 1 1 0 'X' 'X' 0 0 None 0]
 [0 0 0 0 1 1 0 'X' 'X' 0 0 1 None]]

[[None 0 0 0 0 0 0 'X' 'X' 0 0 0 0]
 [1 None 0 0 0 0 0 'X' 'X' 0 0 0 0]
 [1 0 None 0 0 0 0 'X' 'X' 0 0 0 0]
 [1 0 0 None 0 0 0 'X' 'X' 0 0 0 0]
 [1 0 0 0 None 0 0 'X' 'X' 0 0 0 0]
 [1 0 0 0 0 None 0 'X' 'X' 0 0 0 0]
 [1 0 0 1 0 0 None 'X' 'X' 0 0 0 0]
 ['X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X']
 ['X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X' 'X']
 [1 0 0 1 0 0 1 'X' 'X' None 0 0 0]
 [1 0 0 1 0 0 1 'X' 'X' 0 None 0 0]
 [1 0 0 1 0 0 1 'X' 'X' 0 0 None 0]
 [1 0 0 1 0 0 1 'X' 'X' 0 0 0 None]]
 '''

'''
print(get_column(Before_matrix,0))

print(Before_matrix[node_list.index(E)])
print(get_column(Before_matrix,node_list.index(E)))
print(compare_with_average_matrix(E,Before_matrix,node_list,Inside_matrix))


print(compare_with_average_matrix(E, Before_matrix, node_list, average1))

print(calculate_weight(E, node_list, Before_matrix, Inside_matrix, average1, average2)) 


print(np.asarray(Before_matrix).view())
print(np.asarray(Inside_matrix).view())


matriz_nueva=modify_Before_matrix(C, A, node_list, Before_matrix, Inside_matrix)
matriz_nueva2=modify_Inside_matrix(C, A, node_list,  Inside_matrix)


print(np.asarray(matriz_nueva).view())
print(np.asarray(matriz_nueva2).view())

matriz_nueva=modify_Before_matrix(B, C, node_list, Before_matrix, Inside_matrix)
matriz_nueva2=modify_Inside_matrix(B, C, node_list,  Inside_matrix)

print(np.asarray(matriz_nueva).view())
print(np.asarray(matriz_nueva2).view())
'''

'''
#da un resultado demasiado bajo, tiene que haber algo mal
#creo que no tiene sentido que haya que darle las matrices Inside y Before, lo ideal sería que le preguntases por el peso 
# de un nodo teniendo en cuenta la matriz Average (y tal vez los argumentos y el nombre del fichero del que sacar el test)
'''
#en realidad probándolo mejor ha dado un resultado aceptable, y no había tenido en cuenta que hay dos matrices promedio
#y hay muchos datos que necesitamos para calcular las matrices Before y Inside
#así que quizá tiene sentido calcularlas fuera de "calculate_weight"


#esto ya calcula, dado un nodo y unos datos (almacenados en las matrices Average), un número del 0 al 1 que mide cómo de buena idea es 
# que ese nodo vaya en esa posición (no es exactamente una probabilidad, pero es parecido)


#ahora hace falta implementar las funciones que añaden esto al programa original
#la idea de momento es que cada vez que un nodo va a ser insertado, el programa calcula el peso del nodo en esa posición.
#usa ese nodo como una probabilidad de insertar el nodo ahí, en lugar de la probabilidad fija que había antes (era 0.7 creo)
#así, aunque tarda más tiempo por iteración por culpa de tener que calcular el peso, 
# en teoría debería ser más inteligente y crear menos tests que no compilen o que vayan mal en general



