def resta(a,b):
    return a-b

def operaciones(a, b, c, d):
    return a - b + (c * d)


class Tienda:
	def __init__(self, ganancias, stock):
		self.ganancias = ganancias
		self.stock = stock

	def ganar_dinero(self, ingresos):
		self.ganancias += ingresos

	def vender(self, ingresos, productos_vendidos):
		self.ganancias += ingresos
		self.stock -= productos_vendidos
